@echo off
setlocal
rem Revert the wrapper: restore real ffmpeg.exe / ffplay.exe from *.origin.exe.

cd /d "%~dp0"

tasklist /FI "IMAGENAME eq Radikool.exe" 2>nul | find /I "Radikool.exe" >nul
if not errorlevel 1 (
  echo [ERROR] RadiKool is running. Close it and run again.
  pause
  exit /b 1
)

if not exist "ffmpeg.origin.exe" if not exist "ffplay.origin.exe" (
  echo [INFO] No *.origin.exe found. Wrapper does not seem to be installed.
  pause
  exit /b 0
)

if exist "ffmpeg.origin.exe" (
  if exist "ffmpeg.exe" erase "ffmpeg.exe"
  ren "ffmpeg.origin.exe" "ffmpeg.exe"
)
if exist "ffplay.origin.exe" (
  if exist "ffplay.exe" erase "ffplay.exe"
  ren "ffplay.origin.exe" "ffplay.exe"
)

echo Reverted: ffmpeg.exe / ffplay.exe restored to the real binaries.
pause
endlocal
